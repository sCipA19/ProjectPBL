<?php
session_start();

// Mengecek apakah pengguna sudah login
if (!isset($_SESSION['username'])) {
    header("Location: ../Login/index2.php"); // Jika belum login, arahkan ke halaman login
    exit();
}

// Koneksi ke database
$serverName = "DESKTOP-F6C9C3F\\DBMS2023"; // Ganti dengan nama server
$database = "PBL"; // Ganti dengan nama database
$username = ""; // Kosongkan karena menggunakan Windows Authentication
$password = ""; // Kosongkan karena menggunakan Windows Authentication

try {
    $conn = new PDO("sqlsrv:Server=$serverName;Database=$database", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Koneksi gagal: " . $e->getMessage());
}

// Ambil detail pelanggaran berdasarkan NIM
try {
    $sql = "SELECT nim, nama, pelanggaran, tingkat_pelanggaran, kompensasi, tenggat_waktu FROM pelanggaran";
    $result = $conn->query($sql);
    $pelanggaran = $result->fetch(PDO::FETCH_ASSOC); // Ambil data pertama
} catch (PDOException $e) {
    die("Error saat mengambil data pelanggaran: " . $e->getMessage());
}

// Data pengguna
$user = [
    'name' => 'My Babby Findia',
    'nim' => '2341760007',
    'angkatan' => 2023,
    'email' => 'Mybabyfind@gmail.com',
    'kota_lahir' => 'Malang',
    'jenis_kelamin' => 'Perempuan',
];

// Halaman aktif
$page = isset($_GET['page']) ? $_GET['page'] : 'dashboard';
// Proses upload file jika ada
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_FILES['uploadFile'])) {
        $fileTmpName = $_FILES['uploadFile']['tmp_name'];
        $fileName = $_FILES['uploadFile']['name'];
        $fileType = $_FILES['uploadFile']['type'];
        echo 'Nama File yang Diupload: ' . $fileName;
    }
}

// Sertakan file template php
include 'C:\laragon\www\dasarWeb\Project PBL\Mahasiswa\template.php';
?>
