<?php
// Memastikan sesi hanya dimulai sekali
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Mengecek apakah pengguna sudah login
if (!isset($_SESSION['username'])) {
    header("Location: ../Login/index2.php"); // Jika belum login, arahkan ke halaman login
    exit();
}

// Koneksi ke database
$serverName = "DESKTOP-F6C9C3F\\DBMS2023"; // Ganti dengan nama server
$database = "PBL"; // Ganti dengan nama database Anda
$username = ""; // Kosongkan karena menggunakan Windows Authentication
$password = ""; // Kosongkan karena menggunakan Windows Authentication

try {
    $conn = new PDO("sqlsrv:Server=$serverName;Database=$database", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Koneksi gagal: " . $e->getMessage());
}

// Dummy data untuk sesi pengguna (Ganti dengan data aktual dari database)
$user = [
    'name' => 'My babby Findia',
    'nim' => '2341760007',
    'angkatan' => '2020',
    'email' => 'email@example.com',
    'kota_lahir' => 'Surabaya',
    'jenis_kelamin' => 'Laki-laki'
];
$page = isset($_GET['page']) ? $_GET['page'] : 'dashboard';
?>

<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sistem Informasi Tata Tertib JTI</title>
    <link rel="stylesheet" href="mhs.css">

    <!-- Menambahkan Font Awesome CDN -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>

<body>
    <!-- Sidebar -->
    <aside class="sidebar">
        <div class="profile-section">
            <!-- Label ANUKRAMA di atas gambar profil -->
            <p class="anukrama-label">ANUKRAMA</p>
            <img src="images/profile.jpg" alt="Profile Picture" class="profile-picture" id="profile-trigger">
            <p class="profile-name"><?= htmlspecialchars($user['name']) ?></p>
        </div>
        <nav class="menu">
            <ul>
                <li class="<?= $page == 'dashboard' ? 'active' : '' ?>">
                    <a href="?page=dashboard">
                        <i class="fas fa-tachometer-alt"></i> Dashboard TATIB
                    </a>
                </li>
                <li class="<?= $page == 'pelanggaran' ? 'active' : '' ?>">
                    <a href="?page=pelanggaran">
                        <i class="fas fa-clipboard-list"></i> Daftar Pelanggaran
                    </a>
                </li>
                <li>
                    <a href="logout.php">
                        <i class="fas fa-sign-out-alt"></i> Logout
                    </a>
                </li>
            </ul>
        </nav>
    </aside>

    <!-- Main Content -->
    <main class="main-content">
        <?php if ($page == 'dashboard'): ?>
            <h1>Hi <?= htmlspecialchars($user['name']) ?></h1>
            <p>Selamat Datang di Dashboard Mahasiswa</p>
            <button class="btn-main" onclick="location.href='?page=pelanggaran'">Daftar Pelanggaran</button>
            <div class="info-container">
                <div class="info-card info-red">
                    <h2>Total Pelanggaran</h2>
                    <p>120 Pelanggaran</p>
                </div>
                <div class="info-card info-orange">
                    <h2>Pelanggaran Diproses</h2>
                    <p>50 Pelanggaran</p>
                </div>
                <div class="info-card info-green">
                    <h2>Pelanggaran Selesai</h2>
                    <p>70 Pelanggaran</p>
                </div>
            </div>
        <?php elseif ($page == 'pelanggaran'): ?>
            <h1>Daftar Pelanggaran</h1>
            <p>Daftar pelanggaran yang terdaftar di sistem:</p>
            <table>
                <tr>
                    <th>No.</th>
                    <th>Tanggal</th>
                    <th>Kelas</th>
                    <th>Pelanggaran</th>
                    <th>Tingkat</th>
                    <th>Status</th>
                </tr>
                <!-- Tambahkan data pelanggaran di sini -->
            </table>
        <?php endif; ?>
    </main>

    <!-- Popup Identitas Mahasiswa -->
    <div class="popup" id="profile-popup">
        <div class="popup-content">
            <h2>Identitas Mahasiswa</h2>
            <p><span class="label">Nama</span><span class="value">: <?= htmlspecialchars($user['name']) ?></span></p>
            <p><span class="label">NIM</span><span class="value">: <?= htmlspecialchars($user['nim']) ?></span></p>
            <p><span class="label">Angkatan</span><span class="value">: <?= htmlspecialchars($user['angkatan']) ?></span></p>
            <p><span class="label">Email</span><span class="value">: <?= htmlspecialchars($user['email']) ?></span></p>
            <p><span class="label">Kota Lahir</span><span class="value">: <?= htmlspecialchars($user['kota_lahir']) ?></span></p>
            <p><span class="label">Jenis Kelamin</span><span class="value">: <?= htmlspecialchars($user['jenis_kelamin']) ?></span></p>
            <button class="close" id="close-popup">Tutup</button>
        </div>
    </div>

    <!-- Popup Message -->
    <img src="images/message-icon.png" alt="Message Icon" class="message-icon" id="message-icon">
    <div class="popup" id="message-popup">
        <div class="popup-content">
            <div class="chat-list-container" id="chatList">
                <div class="chat-list-header">Notifikasi</div>
                <div class="chat-list-body">
                    <?php foreach ($notifications as $index => $notif): ?>
                        <div class="chat-list-item" data-index="<?= $index ?>" data-name="<?= htmlspecialchars($notif['name']) ?>" data-message="<?= htmlspecialchars($notif['message']) ?>" data-time="<?= htmlspecialchars($notif['time']) ?>" onclick="showNotificationDetails(this)">
                            <div class="chat-item-info">
                                <span class="chat-item-name"><?= htmlspecialchars($notif['name']) ?></span>
                                <span class="chat-item-time"><?= htmlspecialchars($notif['time']) ?></span>
                            </div>
                            <div class="chat-item-message">
                                <span><?= htmlspecialchars($notif['message']) ?></span>
                                <span class="chat-item-status <?= htmlspecialchars($notif['status']) ?>"><?= ucfirst($notif['status']) ?></span>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
            <button class="close" id="message-popup-close">Tutup</button>
        </div>
    </div>

    <!-- Notification Details Modal -->
    <div class="notification" id="notificationDetails">
        <button class="back-button" onclick="goBack()">Kembali</button>
        <p class="header">To : -</p>
        <p class="header date">-</p>
        <div class="notification-details">
            <div class="row"><span class="label">NIM</span><span class="value">: -</span></div>
            <div class="row"><span class="label">Nama</span><span class="value">: -</span></div>
            <div class="row"><span class="label">Pelanggaran</span><span class="value">: -</span></div>
            <div class="row"><span class="label">Tingkat Pelanggaran</span><span class="value">: -</span></div>
            <div class="row"><span class="label">Kompensasi</span><span class="value">: -</span></div>
            <div class="row"><span class="label">Tenggat Waktu</span><span class="value">: -</span></div>
            <form action="upload.php" method="POST" enctype="multipart/form-data">
                <div class="row">
                    <span class="label">Form Pengumpulan</span><span class="colon">:</span>
                    <span class="value">
                        <input type="file" id="uploadFile" name="uploadFile" class="file-input" accept="application/pdf" onchange="displayFileName();">
                        <div id="fileName"></div>
                    </span>
                </div>
            </form>
        </div>
    </div>
    <script src="main.js"></script>
</body>

</html>
