<?php
session_start();

// Mengecek apakah pengguna sudah login
if (!isset($_SESSION['username'])) {
    header("Location: ../Login/index2.php"); // Jika belum login, arahkan ke halaman login
    exit();
}


// Koneksi ke database
$serverName = "DESKTOP-F6C9C3F\\DBMS2023"; // Ganti dengan nama server
$database = "PBL"; // Ganti dengan nama database
$username = ""; // Kosongkan karena menggunakan Windows Authentication
$password = ""; // Kosongkan karena menggunakan Windows Authentication

try {
    $conn = new PDO("sqlsrv:Server=$serverName;Database=$database", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Koneksi gagal: " . $e->getMessage());
}

// Query untuk mengambil jumlah dosen
$sqlDosen = "SELECT COUNT(*) FROM tb_dosen"; // Ganti dengan tabel dosen
$stmtDosen = $conn->prepare($sqlDosen);
$stmtDosen->execute();
$dosenCount = $stmtDosen->fetchColumn();

// Query untuk mengambil jumlah mahasiswa
$sqlMahasiswa = "SELECT COUNT(*) FROM tb_mahasiswa"; // Ganti dengan tabel mahasiswa
$stmtMahasiswa = $conn->prepare($sqlMahasiswa);
$stmtMahasiswa->execute();
$mahasiswaCount = $stmtMahasiswa->fetchColumn();
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard TATIB - ANUKRAMA</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="dash.css" rel="stylesheet">
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <div class="col-md-3 sidebar">
                <h4>ANUKRAMA</h4>
                <div class="profile">
                    <img src="image/Dosen2.jpg" alt="Profile Picture">
                    <h5>PURNOMO SUJARWO S.Pd S.Ag</h5>
                </div>
                <nav class="nav flex-column">
                    <a href="#" class="nav-link active">
                        <i class="fas fa-home"></i> Dashboard TATIB
                    </a>
                    <a href="laporkan_mahasiswa.php" class="nav-link">
                        <i class="fas fa-clipboard-list"></i> Laporkan Pelanggaran
                    </a>
                    <a href="logout.php" class="nav-link text-danger">
                        <i class="fas fa-sign-out-alt"></i> Logout
                    </a>
                </nav>
            </div>

            <!-- Main Content -->
            <div class="col-md-9 p-4">
                <h1 class="fw-bold">Selamat Datang</h1>
                <p>di sistem Anukrama. Pilih menu di sidebar untuk mulai laporkan pelanggaran, dan notifikasi.</p>
                
                <!-- Tabel Pelanggaran -->
                <div class="table-container mt-4">
                    <table class="table table-bordered">
                        <thead class="table-primary">
                            <tr>
                                <th>No.</th>
                                <th>NIM</th>
                                <th>Nama Mahasiswa</th>
                                <th>Kelas</th>
                                <th>Pelanggaran</th>
                                <th>Tingkat</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $data = [
                                ['nim' => '2341760007', 'nama' => 'Rizky Roza Rahim', 'kelas' => 'SIB -2B', 'pelanggaran' => 'Tidak memakai seragam', 'tingkat' => 'I', 'status' => 'Proses'],
                                ['nim' => '2341760007', 'nama' => 'Syifa Revalina', 'kelas' => 'SIB -2B', 'pelanggaran' => 'Merokok di area kampus', 'tingkat' => 'III', 'status' => 'Proses'],
                                ['nim' => '2341760007', 'nama' => 'My Babby Findia', 'kelas' => 'SIB -2B', 'pelanggaran' => 'Mabuk di dalam kelas', 'tingkat' => 'IV', 'status' => 'Selesai'],
                            ];
                            foreach ($data as $index => $row) {
                                echo "<tr>";
                                echo "<td>" . ($index + 1) . "</td>";
                                echo "<td>" . $row['nim'] . "</td>";
                                echo "<td>" . $row['nama'] . "</td>";
                                echo "<td>" . $row['kelas'] . "</td>";
                                echo "<td>" . $row['pelanggaran'] . "</td>";
                                echo "<td>" . $row['tingkat'] . "</td>";
                                echo "<td>";
                                echo $row['status'] === 'Proses' 
                                    ? "<span class='badge badge-danger'>Proses</span>" 
                                    : "<span class='badge badge-success'>Selesai</span>";
                                echo "</td>";
                                echo "</tr>";
                            }
                            ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    
    <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/js/all.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
