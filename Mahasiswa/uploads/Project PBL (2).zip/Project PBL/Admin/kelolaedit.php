<?php
session_start();
require '../koneksi/kon.php';

if (!isset($_SESSION['username'])) {
    header("Location: ../index2.php");
    exit();
}

try {
    $conn = new PDO("sqlsrv:Server=DESKTOP-F6C9C3F\\DBMS2023;Database=PBL", "", "");
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        // Ambil data dari form
        $nim = $_POST['nim'];
        $nama_mahasiswa = $_POST['nama_mahasiswa'];
        $kelas = $_POST['kelas'];
        $pelanggaran = $_POST['pelanggaran'];
        $tingkat = $_POST['tingkat'];

        // Validasi keberadaan NIM di tabel tb_mahasiswa
        $stmt_mahasiswa = $conn->prepare("SELECT id_mahasiswa FROM tb_mahasiswa WHERE nim = :nim");
        $stmt_mahasiswa->bindParam(':nim', $nim);
        $stmt_mahasiswa->execute();
        $result = $stmt_mahasiswa->fetch(PDO::FETCH_ASSOC);

        if (!$result) {
            echo "<script>alert('Mahasiswa dengan NIM tersebut tidak ditemukan!'); window.history.back();</script>";
            exit();
        }

        $id_mahasiswa = $result['id_mahasiswa'];

        // Upload file bukti
        $bukti = null;
        if (!empty($_FILES['bukti']['name'])) {
            $targetDir = "uploads/";
            $bukti = $targetDir . basename($_FILES['bukti']['name']);
            if (!move_uploaded_file($_FILES['bukti']['tmp_name'], $bukti)) {
                echo "<script>alert('Gagal mengunggah bukti!'); window.history.back();</script>";
                exit();
            }
        }

        // Insert data ke database
        $stmt = $conn->prepare("INSERT INTO tb_kelolatatib (id_mahasiswa, nim, nama_mahasiswa, kelas, pelanggaran, tingkat, bukti) 
                                VALUES (:id_mahasiswa, :nim, :nama_mahasiswa, :kelas, :pelanggaran, :tingkat, :bukti)");
        $stmt->bindParam(':id_mahasiswa', $id_mahasiswa);
        $stmt->bindParam(':nim', $nim);
        $stmt->bindParam(':nama_mahasiswa', $nama_mahasiswa);
        $stmt->bindParam(':kelas', $kelas);
        $stmt->bindParam(':pelanggaran', $pelanggaran);
        $stmt->bindParam(':tingkat', $tingkat);
        $stmt->bindParam(':bukti', $bukti);

        if ($stmt->execute()) {
            echo "<script>alert('Data berhasil ditambahkan!'); window.location.href='kelola.php';</script>";
        } else {
            echo "<script>alert('Gagal menambahkan data!'); window.history.back();</script>";
        }
    }
} catch (PDOException $e) {
    die("Koneksi gagal: " . $e->getMessage());
}
?>



<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Anukrama</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="style_beranda.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">
    <script>
        // JavaScript function to add a card
        function addCard() {
            const cardContainer = document.getElementById("cardContainer");

            // Create a new card element
            const card = document.createElement("div");
            card.className = "card mb-3";
            card.innerHTML = `
        <div class="card-body">
          <p class="card-text">NIM: New NIM</p>
          <p class="card-text">Nama Mahasiswa: New Name</p>
          <p class="card-text">Kelas: New Class</p>
          <p class="card-text">Pelanggaran: New Violation</p>
          <p class="card-text">Tingkat Pelanggaran: New Level</p>
          <p class="card-text">Tahun Ajaran: New Academic Year</p>
          <div>
            <label for="fileUpload" class="form-label">Upload Bukti Pelanggaran:</label>
            <input type="file" class="form-control mb-3" id="fileUpload">
            <a href="#" class="btn btn-primary btn-sm me-2" title="Edit"><i class="bi bi-pencil-square"></i> Edit</a>
            <a href="#" class="btn btn-danger btn-sm" title="Hapus"><i class="bi bi-trash"></i> Hapus</a>
          </div>
        </div>
      `;

            cardContainer.appendChild(card);
        }
    </script>
</head>

<body>
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <div class="col-md-3 sidebar vh-100">
                <div class="text-center mt-4">
                    <h3 class="text-uppercase fw-bold">Anukrama</h3>
                    <img src="./img/pic.jpeg" alt="Suprapto" class="rounded-circle mt-3" width="80">
                    <h5 class="mt-2">Suprapto</h5>
                </div>
                <ul class="nav flex-column mt-4">
                    <li class="nav-item">
                        <a href="beranda.php" class="nav-link">
                            <i class="bi bi-house-door me-2"></i>Dashboard
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="pelanggaran.php" class="nav-link">
                            <i class="bi bi-list-task me-2"></i>Daftar Pelanggaran
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="kelola.php" class="nav-link">
                            <i class="bi bi-gear me-2"></i>Kelola Tata Tertib
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="#" class="nav-link">
                            <i class="bi bi-bell me-2"></i>Notifikasi Mahasiswa
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="logout.php" class="nav-link">
                            <i class="bi bi-box-arrow-right me-2"></i>Logout
                        </a>
                    </li>
                </ul>
            </div>

            <!-- Main Content -->
            <div class="col-md-9 p-4" id="main-content">
                <h2>Kelola Tata Tertib</h2>
                <p>Tambahkan, edit, atau hapus aturan tata tertib di bawah ini:</p>

                <!-- Button to Add Card -->
                <button type="submit" class="btn btn-success mb-3">Tambah Pelanggaran</button>



                <!-- Card Container -->
                <div id="cardContainer">
                    <div class="card mb-3">
                        <div class="card-body">
                        <form action="kelola.php" method="POST" enctype="multipart/form-data">
    <!-- Input NIM -->
    <div class="mb-3">
        <label for="nim" class="form-label">NIM</label>
        <input type="text" class="form-control" id="nim" name="nim" placeholder="Masukkan NIM" required>
    </div>
    <!-- Input Nama Mahasiswa -->
    <div class="mb-3">
        <label for="nama_mahasiswa" class="form-label">Nama Mahasiswa</label>
        <input type="text" class="form-control" id="nama_mahasiswa" name="nama_mahasiswa" placeholder="Masukkan Nama Mahasiswa" required>
    </div>
    <!-- Input Kelas -->
    <div class="mb-3">
        <label for="kelas" class="form-label">Kelas</label>
        <input type="text" class="form-control" id="kelas" name="kelas" placeholder="Masukkan Kelas" required>
    </div>
    <!-- Input Pelanggaran -->
    <div class="mb-3">
        <label for="pelanggaran" class="form-label">Pelanggaran</label>
        <input type="text" class="form-control" id="pelanggaran" name="pelanggaran" placeholder="Masukkan Pelanggaran" required>
    </div>
    <!-- Input Tingkat Pelanggaran -->
    <div class="mb-3">
        <label for="tingkat" class="form-label">Tingkat Pelanggaran</label>
        <input type="text" class="form-control" id="tingkat" name="tingkat" placeholder="Masukkan Tingkat Pelanggaran" required>
    </div>
    <!-- Upload Bukti -->
    <div class="mb-3">
        <label for="bukti" class="form-label">Upload Bukti Pelanggaran</label>
        <input type="file" class="form-control" id="bukti" name="bukti" required>
    </div>
    <!-- Tombol Submit -->
    <button type="submit" class="btn btn-success mb-3">Tambah Pelanggaran</button>
</form>
                        </div>
                    </div>

                    <script
                        src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>