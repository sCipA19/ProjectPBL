<?php
// Memulai session dan menghubungkan ke database
session_start();
include('../koneksi/kon.php'); // Pastikan path ini sesuai

// Mengecek apakah form telah disubmit
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Mendapatkan data dari form
    $namaMahasiswa = isset($_POST['namaMahasiswa']) ? $_POST['namaMahasiswa'] : '';
    $nim = isset($_POST['nim']) ? $_POST['nim'] : '';
    $kelas = isset($_POST['kelas']) ? $_POST['kelas'] : '';
    $pelanggaran = isset($_POST['pelanggaran']) ? $_POST['pelanggaran'] : '';
    $tingkatPelanggaran = isset($_POST['tingkatPelanggaran']) ? $_POST['tingkatPelanggaran'] : '';

    // Menyimpan file jika ada
    $fileUpload = isset($_FILES['fileUpload']) ? $_FILES['fileUpload'] : null;

    if ($fileUpload && $fileUpload['error'] === UPLOAD_ERR_OK) {
        // Menyimpan file ke folder dan mendapatkan nama file dan lokasi
        $uploadDir = 'uploads/'; // Sesuaikan dengan direktori penyimpanan file
        $fileName = basename($fileUpload['name']);
        $fileTmpName = $fileUpload['tmp_name'];
        $filePath = $uploadDir . $fileName;

        // Memindahkan file ke lokasi yang ditentukan
        if (move_uploaded_file($fileTmpName, $filePath)) {
            // Mengambil ID dari tabel lain berdasarkan data yang ada
            $idMahasiswa = getIdMahasiswa($nim); // Fungsi untuk mendapatkan id mahasiswa
            $idKls = getIdKelas($kelas); // Fungsi untuk mendapatkan id kelas
            $idPelanggaran = getIdPelanggaran($pelanggaran); // Fungsi untuk mendapatkan id pelanggaran

            // Jika salah satu ID tidak ditemukan, berhenti dan beri pesan kesalahan
            if (!$idMahasiswa || !$idKls || !$idPelanggaran) {
                echo "Gagal mendapatkan ID dari database.";
                exit;
            }

            // Query untuk memasukkan data ke tabel tb_kelolaedit
            $query = "
                INSERT INTO tb_kelolaedit 
                (id_mahasiswa, id_kls, id_pelanggaran, nama_mahasiswa, nim, kelas, pelanggaran, tingkat_pelanggaran, nama_file, lokasi_file)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ";

            // Persiapkan dan eksekusi query
            $stmt = sqlsrv_prepare($conn, $query, array($idMahasiswa, $idKls, $idPelanggaran, $namaMahasiswa, $nim, $kelas, $pelanggaran, $tingkatPelanggaran, $fileName, $filePath));

            if ($stmt === false) {
                die(print_r(sqlsrv_errors(), true));
            }

            if (sqlsrv_execute($stmt)) {
                echo "Data berhasil disimpan!";
            } else {
                echo "Terjadi kesalahan saat menyimpan data!";
            }
        } else {
            echo "Gagal mengunggah file.";
        }
    } else {
        echo "Tidak ada file yang diunggah atau terjadi kesalahan pada file.";
    }
}

// Fungsi untuk mendapatkan id_mahasiswa berdasarkan NIM
function getIdMahasiswa($nim) {
    global $conn;
    $query = "SELECT id_mahasiswa FROM tb_mahasiswa WHERE nim = ?";
    $stmt = sqlsrv_prepare($conn, $query, array($nim));
    if (sqlsrv_execute($stmt)) {
        $result = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC);
        return $result ? $result['id_mahasiswa'] : null; // Mengembalikan null jika tidak ditemukan
    }
    return null;
}

// Fungsi untuk mendapatkan id_kls berdasarkan nama kelas
function getIdKelas($kelas) {
    global $conn;
    $query = "SELECT id_kls FROM tb_kelas WHERE kelas = ?";
    $stmt = sqlsrv_prepare($conn, $query, array($kelas));
    if (sqlsrv_execute($stmt)) {
        $result = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC);
        return $result ? $result['id_kls'] : null; // Mengembalikan null jika tidak ditemukan
    }
    return null;
}

// Fungsi untuk mendapatkan id_pelanggaran berdasarkan nama pelanggaran
function getIdPelanggaran($pelanggaran) {
    global $conn;
    $query = "SELECT id_pelanggaran FROM tb_pelanggaran WHERE pelanggaran = ?";
    $stmt = sqlsrv_prepare($conn, $query, array($pelanggaran));
    if (sqlsrv_execute($stmt)) {
        $result = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC);
        return $result ? $result['id_pelanggaran'] : null; // Mengembalikan null jika tidak ditemukan
    }
    return null;
}
?>
